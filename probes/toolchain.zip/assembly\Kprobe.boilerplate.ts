import { System, Protobuf, authority } from "@koinos/sdk-as";
import { kprobe } from "./proto/kprobe";

export class Kprobe {
  authorize(args: authority.authorize_arguments): authority.authorize_result {
    // const call = args.call;
    // const type = args.type;

    // YOUR CODE HERE

    const res = new authority.authorize_result();
    res.value = true;

    return res;
  }

  info(args: kprobe.info_arguments): kprobe.info_result {
    // YOUR CODE HERE

    const res = new kprobe.info_result();
    // res.contract = ;
    // res.owner = ;
    // res.koin = ;
    // res.vhp = ;
    // res.pob = ;
    // res.koin_balance = ;
    // res.vhp_balance = ;
    // res.mana = ;
    // res.head_height = ;
    // res.credited_total = ;
    // res.pings = ;
    // res.producer_key = ;

    return res;
  }

  init(args: kprobe.init_arguments): kprobe.init_result {
    // const owner = args.owner;

    // YOUR CODE HERE

    const res = new kprobe.init_result();

    return res;
  }

  deposit_vhp(args: kprobe.deposit_vhp_arguments): kprobe.deposit_vhp_result {
    // const from = args.from;
    // const amount = args.amount;

    // YOUR CODE HERE

    const res = new kprobe.deposit_vhp_result();
    // res.credited = ;

    return res;
  }

  deposit_koin(
    args: kprobe.deposit_koin_arguments
  ): kprobe.deposit_koin_result {
    // const from = args.from;
    // const amount = args.amount;

    // YOUR CODE HERE

    const res = new kprobe.deposit_koin_result();
    // res.credited = ;

    return res;
  }

  withdraw_vhp(
    args: kprobe.withdraw_vhp_arguments
  ): kprobe.withdraw_vhp_result {
    // const to = args.to;
    // const amount = args.amount;

    // YOUR CODE HERE

    const res = new kprobe.withdraw_vhp_result();

    return res;
  }

  compound(args: kprobe.compound_arguments): kprobe.compound_result {
    // const keep_reserve = args.keep_reserve;

    // YOUR CODE HERE

    const res = new kprobe.compound_result();
    // res.burned = ;
    // res.mana_before = ;

    return res;
  }

  register_key(
    args: kprobe.register_key_arguments
  ): kprobe.register_key_result {
    // const public_key = args.public_key;

    // YOUR CODE HERE

    const res = new kprobe.register_key_result();

    return res;
  }

  ping(args: kprobe.ping_arguments): kprobe.ping_result {
    // const note = args.note;

    // YOUR CODE HERE

    const res = new kprobe.ping_result();
    // res.count = ;
    // res.payer = ;

    return res;
  }

  stress(args: kprobe.stress_arguments): kprobe.stress_result {
    // const writes = args.writes;
    // const bins = args.bins;

    // YOUR CODE HERE

    const res = new kprobe.stress_result();
    // res.sum = ;

    return res;
  }

  sweep(args: kprobe.sweep_arguments): kprobe.sweep_result {
    // YOUR CODE HERE

    const res = new kprobe.sweep_result();
    // res.koin = ;
    // res.vhp = ;

    return res;
  }
}
