import { Writer, Reader } from "as-proto";

export namespace kprobe {
  export class config_object {
    static encode(message: config_object, writer: Writer): void {
      const unique_name_owner = message.owner;
      if (unique_name_owner !== null) {
        writer.uint32(10);
        writer.bytes(unique_name_owner);
      }
    }

    static decode(reader: Reader, length: i32): config_object {
      const end: usize = length < 0 ? reader.end : reader.ptr + length;
      const message = new config_object();

      while (reader.ptr < end) {
        const tag = reader.uint32();
        switch (tag >>> 3) {
          case 1:
            message.owner = reader.bytes();
            break;

          default:
            reader.skipType(tag & 7);
            break;
        }
      }

      return message;
    }

    owner: Uint8Array | null;

    constructor(owner: Uint8Array | null = null) {
      this.owner = owner;
    }
  }

  @unmanaged
  export class balance_object {
    static encode(message: balance_object, writer: Writer): void {
      if (message.value != 0) {
        writer.uint32(8);
        writer.uint64(message.value);
      }
    }

    static decode(reader: Reader, length: i32): balance_object {
      const end: usize = length < 0 ? reader.end : reader.ptr + length;
      const message = new balance_object();

      while (reader.ptr < end) {
        const tag = reader.uint32();
        switch (tag >>> 3) {
          case 1:
            message.value = reader.uint64();
            break;

          default:
            reader.skipType(tag & 7);
            break;
        }
      }

      return message;
    }

    value: u64;

    constructor(value: u64 = 0) {
      this.value = value;
    }
  }

  @unmanaged
  export class info_arguments {
    static encode(message: info_arguments, writer: Writer): void {}

    static decode(reader: Reader, length: i32): info_arguments {
      const end: usize = length < 0 ? reader.end : reader.ptr + length;
      const message = new info_arguments();

      while (reader.ptr < end) {
        const tag = reader.uint32();
        switch (tag >>> 3) {
          default:
            reader.skipType(tag & 7);
            break;
        }
      }

      return message;
    }

    constructor() {}
  }

  export class info_result {
    static encode(message: info_result, writer: Writer): void {
      const unique_name_contract = message.contract;
      if (unique_name_contract !== null) {
        writer.uint32(10);
        writer.bytes(unique_name_contract);
      }

      const unique_name_owner = message.owner;
      if (unique_name_owner !== null) {
        writer.uint32(18);
        writer.bytes(unique_name_owner);
      }

      const unique_name_koin = message.koin;
      if (unique_name_koin !== null) {
        writer.uint32(26);
        writer.bytes(unique_name_koin);
      }

      const unique_name_vhp = message.vhp;
      if (unique_name_vhp !== null) {
        writer.uint32(34);
        writer.bytes(unique_name_vhp);
      }

      const unique_name_pob = message.pob;
      if (unique_name_pob !== null) {
        writer.uint32(42);
        writer.bytes(unique_name_pob);
      }

      if (message.koin_balance != 0) {
        writer.uint32(48);
        writer.uint64(message.koin_balance);
      }

      if (message.vhp_balance != 0) {
        writer.uint32(56);
        writer.uint64(message.vhp_balance);
      }

      if (message.mana != 0) {
        writer.uint32(64);
        writer.uint64(message.mana);
      }

      if (message.head_height != 0) {
        writer.uint32(72);
        writer.uint64(message.head_height);
      }

      if (message.credited_total != 0) {
        writer.uint32(80);
        writer.uint64(message.credited_total);
      }

      if (message.pings != 0) {
        writer.uint32(88);
        writer.uint64(message.pings);
      }

      const unique_name_producer_key = message.producer_key;
      if (unique_name_producer_key !== null) {
        writer.uint32(98);
        writer.bytes(unique_name_producer_key);
      }
    }

    static decode(reader: Reader, length: i32): info_result {
      const end: usize = length < 0 ? reader.end : reader.ptr + length;
      const message = new info_result();

      while (reader.ptr < end) {
        const tag = reader.uint32();
        switch (tag >>> 3) {
          case 1:
            message.contract = reader.bytes();
            break;

          case 2:
            message.owner = reader.bytes();
            break;

          case 3:
            message.koin = reader.bytes();
            break;

          case 4:
            message.vhp = reader.bytes();
            break;

          case 5:
            message.pob = reader.bytes();
            break;

          case 6:
            message.koin_balance = reader.uint64();
            break;

          case 7:
            message.vhp_balance = reader.uint64();
            break;

          case 8:
            message.mana = reader.uint64();
            break;

          case 9:
            message.head_height = reader.uint64();
            break;

          case 10:
            message.credited_total = reader.uint64();
            break;

          case 11:
            message.pings = reader.uint64();
            break;

          case 12:
            message.producer_key = reader.bytes();
            break;

          default:
            reader.skipType(tag & 7);
            break;
        }
      }

      return message;
    }

    contract: Uint8Array | null;
    owner: Uint8Array | null;
    koin: Uint8Array | null;
    vhp: Uint8Array | null;
    pob: Uint8Array | null;
    koin_balance: u64;
    vhp_balance: u64;
    mana: u64;
    head_height: u64;
    credited_total: u64;
    pings: u64;
    producer_key: Uint8Array | null;

    constructor(
      contract: Uint8Array | null = null,
      owner: Uint8Array | null = null,
      koin: Uint8Array | null = null,
      vhp: Uint8Array | null = null,
      pob: Uint8Array | null = null,
      koin_balance: u64 = 0,
      vhp_balance: u64 = 0,
      mana: u64 = 0,
      head_height: u64 = 0,
      credited_total: u64 = 0,
      pings: u64 = 0,
      producer_key: Uint8Array | null = null
    ) {
      this.contract = contract;
      this.owner = owner;
      this.koin = koin;
      this.vhp = vhp;
      this.pob = pob;
      this.koin_balance = koin_balance;
      this.vhp_balance = vhp_balance;
      this.mana = mana;
      this.head_height = head_height;
      this.credited_total = credited_total;
      this.pings = pings;
      this.producer_key = producer_key;
    }
  }

  export class init_arguments {
    static encode(message: init_arguments, writer: Writer): void {
      const unique_name_owner = message.owner;
      if (unique_name_owner !== null) {
        writer.uint32(10);
        writer.bytes(unique_name_owner);
      }
    }

    static decode(reader: Reader, length: i32): init_arguments {
      const end: usize = length < 0 ? reader.end : reader.ptr + length;
      const message = new init_arguments();

      while (reader.ptr < end) {
        const tag = reader.uint32();
        switch (tag >>> 3) {
          case 1:
            message.owner = reader.bytes();
            break;

          default:
            reader.skipType(tag & 7);
            break;
        }
      }

      return message;
    }

    owner: Uint8Array | null;

    constructor(owner: Uint8Array | null = null) {
      this.owner = owner;
    }
  }

  @unmanaged
  export class init_result {
    static encode(message: init_result, writer: Writer): void {}

    static decode(reader: Reader, length: i32): init_result {
      const end: usize = length < 0 ? reader.end : reader.ptr + length;
      const message = new init_result();

      while (reader.ptr < end) {
        const tag = reader.uint32();
        switch (tag >>> 3) {
          default:
            reader.skipType(tag & 7);
            break;
        }
      }

      return message;
    }

    constructor() {}
  }

  export class deposit_vhp_arguments {
    static encode(message: deposit_vhp_arguments, writer: Writer): void {
      const unique_name_from = message.from;
      if (unique_name_from !== null) {
        writer.uint32(10);
        writer.bytes(unique_name_from);
      }

      if (message.amount != 0) {
        writer.uint32(16);
        writer.uint64(message.amount);
      }
    }

    static decode(reader: Reader, length: i32): deposit_vhp_arguments {
      const end: usize = length < 0 ? reader.end : reader.ptr + length;
      const message = new deposit_vhp_arguments();

      while (reader.ptr < end) {
        const tag = reader.uint32();
        switch (tag >>> 3) {
          case 1:
            message.from = reader.bytes();
            break;

          case 2:
            message.amount = reader.uint64();
            break;

          default:
            reader.skipType(tag & 7);
            break;
        }
      }

      return message;
    }

    from: Uint8Array | null;
    amount: u64;

    constructor(from: Uint8Array | null = null, amount: u64 = 0) {
      this.from = from;
      this.amount = amount;
    }
  }

  @unmanaged
  export class deposit_vhp_result {
    static encode(message: deposit_vhp_result, writer: Writer): void {
      if (message.credited != 0) {
        writer.uint32(8);
        writer.uint64(message.credited);
      }
    }

    static decode(reader: Reader, length: i32): deposit_vhp_result {
      const end: usize = length < 0 ? reader.end : reader.ptr + length;
      const message = new deposit_vhp_result();

      while (reader.ptr < end) {
        const tag = reader.uint32();
        switch (tag >>> 3) {
          case 1:
            message.credited = reader.uint64();
            break;

          default:
            reader.skipType(tag & 7);
            break;
        }
      }

      return message;
    }

    credited: u64;

    constructor(credited: u64 = 0) {
      this.credited = credited;
    }
  }

  export class deposit_koin_arguments {
    static encode(message: deposit_koin_arguments, writer: Writer): void {
      const unique_name_from = message.from;
      if (unique_name_from !== null) {
        writer.uint32(10);
        writer.bytes(unique_name_from);
      }

      if (message.amount != 0) {
        writer.uint32(16);
        writer.uint64(message.amount);
      }
    }

    static decode(reader: Reader, length: i32): deposit_koin_arguments {
      const end: usize = length < 0 ? reader.end : reader.ptr + length;
      const message = new deposit_koin_arguments();

      while (reader.ptr < end) {
        const tag = reader.uint32();
        switch (tag >>> 3) {
          case 1:
            message.from = reader.bytes();
            break;

          case 2:
            message.amount = reader.uint64();
            break;

          default:
            reader.skipType(tag & 7);
            break;
        }
      }

      return message;
    }

    from: Uint8Array | null;
    amount: u64;

    constructor(from: Uint8Array | null = null, amount: u64 = 0) {
      this.from = from;
      this.amount = amount;
    }
  }

  @unmanaged
  export class deposit_koin_result {
    static encode(message: deposit_koin_result, writer: Writer): void {
      if (message.credited != 0) {
        writer.uint32(8);
        writer.uint64(message.credited);
      }
    }

    static decode(reader: Reader, length: i32): deposit_koin_result {
      const end: usize = length < 0 ? reader.end : reader.ptr + length;
      const message = new deposit_koin_result();

      while (reader.ptr < end) {
        const tag = reader.uint32();
        switch (tag >>> 3) {
          case 1:
            message.credited = reader.uint64();
            break;

          default:
            reader.skipType(tag & 7);
            break;
        }
      }

      return message;
    }

    credited: u64;

    constructor(credited: u64 = 0) {
      this.credited = credited;
    }
  }

  export class withdraw_vhp_arguments {
    static encode(message: withdraw_vhp_arguments, writer: Writer): void {
      const unique_name_to = message.to;
      if (unique_name_to !== null) {
        writer.uint32(10);
        writer.bytes(unique_name_to);
      }

      if (message.amount != 0) {
        writer.uint32(16);
        writer.uint64(message.amount);
      }
    }

    static decode(reader: Reader, length: i32): withdraw_vhp_arguments {
      const end: usize = length < 0 ? reader.end : reader.ptr + length;
      const message = new withdraw_vhp_arguments();

      while (reader.ptr < end) {
        const tag = reader.uint32();
        switch (tag >>> 3) {
          case 1:
            message.to = reader.bytes();
            break;

          case 2:
            message.amount = reader.uint64();
            break;

          default:
            reader.skipType(tag & 7);
            break;
        }
      }

      return message;
    }

    to: Uint8Array | null;
    amount: u64;

    constructor(to: Uint8Array | null = null, amount: u64 = 0) {
      this.to = to;
      this.amount = amount;
    }
  }

  @unmanaged
  export class withdraw_vhp_result {
    static encode(message: withdraw_vhp_result, writer: Writer): void {}

    static decode(reader: Reader, length: i32): withdraw_vhp_result {
      const end: usize = length < 0 ? reader.end : reader.ptr + length;
      const message = new withdraw_vhp_result();

      while (reader.ptr < end) {
        const tag = reader.uint32();
        switch (tag >>> 3) {
          default:
            reader.skipType(tag & 7);
            break;
        }
      }

      return message;
    }

    constructor() {}
  }

  @unmanaged
  export class compound_arguments {
    static encode(message: compound_arguments, writer: Writer): void {
      if (message.keep_reserve != 0) {
        writer.uint32(8);
        writer.uint64(message.keep_reserve);
      }
    }

    static decode(reader: Reader, length: i32): compound_arguments {
      const end: usize = length < 0 ? reader.end : reader.ptr + length;
      const message = new compound_arguments();

      while (reader.ptr < end) {
        const tag = reader.uint32();
        switch (tag >>> 3) {
          case 1:
            message.keep_reserve = reader.uint64();
            break;

          default:
            reader.skipType(tag & 7);
            break;
        }
      }

      return message;
    }

    keep_reserve: u64;

    constructor(keep_reserve: u64 = 0) {
      this.keep_reserve = keep_reserve;
    }
  }

  @unmanaged
  export class compound_result {
    static encode(message: compound_result, writer: Writer): void {
      if (message.burned != 0) {
        writer.uint32(8);
        writer.uint64(message.burned);
      }

      if (message.mana_before != 0) {
        writer.uint32(16);
        writer.uint64(message.mana_before);
      }
    }

    static decode(reader: Reader, length: i32): compound_result {
      const end: usize = length < 0 ? reader.end : reader.ptr + length;
      const message = new compound_result();

      while (reader.ptr < end) {
        const tag = reader.uint32();
        switch (tag >>> 3) {
          case 1:
            message.burned = reader.uint64();
            break;

          case 2:
            message.mana_before = reader.uint64();
            break;

          default:
            reader.skipType(tag & 7);
            break;
        }
      }

      return message;
    }

    burned: u64;
    mana_before: u64;

    constructor(burned: u64 = 0, mana_before: u64 = 0) {
      this.burned = burned;
      this.mana_before = mana_before;
    }
  }

  export class register_key_arguments {
    static encode(message: register_key_arguments, writer: Writer): void {
      const unique_name_public_key = message.public_key;
      if (unique_name_public_key !== null) {
        writer.uint32(10);
        writer.bytes(unique_name_public_key);
      }
    }

    static decode(reader: Reader, length: i32): register_key_arguments {
      const end: usize = length < 0 ? reader.end : reader.ptr + length;
      const message = new register_key_arguments();

      while (reader.ptr < end) {
        const tag = reader.uint32();
        switch (tag >>> 3) {
          case 1:
            message.public_key = reader.bytes();
            break;

          default:
            reader.skipType(tag & 7);
            break;
        }
      }

      return message;
    }

    public_key: Uint8Array | null;

    constructor(public_key: Uint8Array | null = null) {
      this.public_key = public_key;
    }
  }

  @unmanaged
  export class register_key_result {
    static encode(message: register_key_result, writer: Writer): void {}

    static decode(reader: Reader, length: i32): register_key_result {
      const end: usize = length < 0 ? reader.end : reader.ptr + length;
      const message = new register_key_result();

      while (reader.ptr < end) {
        const tag = reader.uint32();
        switch (tag >>> 3) {
          default:
            reader.skipType(tag & 7);
            break;
        }
      }

      return message;
    }

    constructor() {}
  }

  export class ping_arguments {
    static encode(message: ping_arguments, writer: Writer): void {
      const unique_name_note = message.note;
      if (unique_name_note !== null) {
        writer.uint32(10);
        writer.string(unique_name_note);
      }
    }

    static decode(reader: Reader, length: i32): ping_arguments {
      const end: usize = length < 0 ? reader.end : reader.ptr + length;
      const message = new ping_arguments();

      while (reader.ptr < end) {
        const tag = reader.uint32();
        switch (tag >>> 3) {
          case 1:
            message.note = reader.string();
            break;

          default:
            reader.skipType(tag & 7);
            break;
        }
      }

      return message;
    }

    note: string | null;

    constructor(note: string | null = null) {
      this.note = note;
    }
  }

  export class ping_result {
    static encode(message: ping_result, writer: Writer): void {
      if (message.count != 0) {
        writer.uint32(8);
        writer.uint64(message.count);
      }

      const unique_name_payer = message.payer;
      if (unique_name_payer !== null) {
        writer.uint32(18);
        writer.bytes(unique_name_payer);
      }
    }

    static decode(reader: Reader, length: i32): ping_result {
      const end: usize = length < 0 ? reader.end : reader.ptr + length;
      const message = new ping_result();

      while (reader.ptr < end) {
        const tag = reader.uint32();
        switch (tag >>> 3) {
          case 1:
            message.count = reader.uint64();
            break;

          case 2:
            message.payer = reader.bytes();
            break;

          default:
            reader.skipType(tag & 7);
            break;
        }
      }

      return message;
    }

    count: u64;
    payer: Uint8Array | null;

    constructor(count: u64 = 0, payer: Uint8Array | null = null) {
      this.count = count;
      this.payer = payer;
    }
  }

  @unmanaged
  export class stress_arguments {
    static encode(message: stress_arguments, writer: Writer): void {
      if (message.writes != 0) {
        writer.uint32(8);
        writer.uint32(message.writes);
      }

      if (message.bins != 0) {
        writer.uint32(16);
        writer.uint32(message.bins);
      }
    }

    static decode(reader: Reader, length: i32): stress_arguments {
      const end: usize = length < 0 ? reader.end : reader.ptr + length;
      const message = new stress_arguments();

      while (reader.ptr < end) {
        const tag = reader.uint32();
        switch (tag >>> 3) {
          case 1:
            message.writes = reader.uint32();
            break;

          case 2:
            message.bins = reader.uint32();
            break;

          default:
            reader.skipType(tag & 7);
            break;
        }
      }

      return message;
    }

    writes: u32;
    bins: u32;

    constructor(writes: u32 = 0, bins: u32 = 0) {
      this.writes = writes;
      this.bins = bins;
    }
  }

  @unmanaged
  export class stress_result {
    static encode(message: stress_result, writer: Writer): void {
      if (message.sum != 0) {
        writer.uint32(8);
        writer.uint64(message.sum);
      }
    }

    static decode(reader: Reader, length: i32): stress_result {
      const end: usize = length < 0 ? reader.end : reader.ptr + length;
      const message = new stress_result();

      while (reader.ptr < end) {
        const tag = reader.uint32();
        switch (tag >>> 3) {
          case 1:
            message.sum = reader.uint64();
            break;

          default:
            reader.skipType(tag & 7);
            break;
        }
      }

      return message;
    }

    sum: u64;

    constructor(sum: u64 = 0) {
      this.sum = sum;
    }
  }

  @unmanaged
  export class sweep_arguments {
    static encode(message: sweep_arguments, writer: Writer): void {}

    static decode(reader: Reader, length: i32): sweep_arguments {
      const end: usize = length < 0 ? reader.end : reader.ptr + length;
      const message = new sweep_arguments();

      while (reader.ptr < end) {
        const tag = reader.uint32();
        switch (tag >>> 3) {
          default:
            reader.skipType(tag & 7);
            break;
        }
      }

      return message;
    }

    constructor() {}
  }

  @unmanaged
  export class sweep_result {
    static encode(message: sweep_result, writer: Writer): void {
      if (message.koin != 0) {
        writer.uint32(8);
        writer.uint64(message.koin);
      }

      if (message.vhp != 0) {
        writer.uint32(16);
        writer.uint64(message.vhp);
      }
    }

    static decode(reader: Reader, length: i32): sweep_result {
      const end: usize = length < 0 ? reader.end : reader.ptr + length;
      const message = new sweep_result();

      while (reader.ptr < end) {
        const tag = reader.uint32();
        switch (tag >>> 3) {
          case 1:
            message.koin = reader.uint64();
            break;

          case 2:
            message.vhp = reader.uint64();
            break;

          default:
            reader.skipType(tag & 7);
            break;
        }
      }

      return message;
    }

    koin: u64;
    vhp: u64;

    constructor(koin: u64 = 0, vhp: u64 = 0) {
      this.koin = koin;
      this.vhp = vhp;
    }
  }
}
