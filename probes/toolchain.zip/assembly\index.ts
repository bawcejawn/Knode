import { System, Protobuf, authority } from "@koinos/sdk-as";
import { Kprobe as ContractClass } from "./Kprobe";
import { kprobe as ProtoNamespace } from "./proto/kprobe";

export function main(): i32 {
  const contractArgs = System.getArguments();
  let retbuf = new Uint8Array(1024);

  const c = new ContractClass();

  switch (contractArgs.entry_point) {
    case 0x4a2dbd90: {
      const args = Protobuf.decode<authority.authorize_arguments>(
        contractArgs.args,
        authority.authorize_arguments.decode
      );
      const res = c.authorize(args);
      retbuf = Protobuf.encode(res, authority.authorize_result.encode);
      break;
    }

    case 0x06271baf: {
      const args = Protobuf.decode<ProtoNamespace.info_arguments>(
        contractArgs.args,
        ProtoNamespace.info_arguments.decode
      );
      const res = c.info(args);
      retbuf = Protobuf.encode(res, ProtoNamespace.info_result.encode);
      break;
    }

    case 0xbb54068a: {
      const args = Protobuf.decode<ProtoNamespace.init_arguments>(
        contractArgs.args,
        ProtoNamespace.init_arguments.decode
      );
      const res = c.init(args);
      retbuf = Protobuf.encode(res, ProtoNamespace.init_result.encode);
      break;
    }

    case 0x8ed1d782: {
      const args = Protobuf.decode<ProtoNamespace.deposit_vhp_arguments>(
        contractArgs.args,
        ProtoNamespace.deposit_vhp_arguments.decode
      );
      const res = c.deposit_vhp(args);
      retbuf = Protobuf.encode(res, ProtoNamespace.deposit_vhp_result.encode);
      break;
    }

    case 0x1fca9c49: {
      const args = Protobuf.decode<ProtoNamespace.deposit_koin_arguments>(
        contractArgs.args,
        ProtoNamespace.deposit_koin_arguments.decode
      );
      const res = c.deposit_koin(args);
      retbuf = Protobuf.encode(res, ProtoNamespace.deposit_koin_result.encode);
      break;
    }

    case 0xc1610dbd: {
      const args = Protobuf.decode<ProtoNamespace.withdraw_vhp_arguments>(
        contractArgs.args,
        ProtoNamespace.withdraw_vhp_arguments.decode
      );
      const res = c.withdraw_vhp(args);
      retbuf = Protobuf.encode(res, ProtoNamespace.withdraw_vhp_result.encode);
      break;
    }

    case 0xee0df97c: {
      const args = Protobuf.decode<ProtoNamespace.compound_arguments>(
        contractArgs.args,
        ProtoNamespace.compound_arguments.decode
      );
      const res = c.compound(args);
      retbuf = Protobuf.encode(res, ProtoNamespace.compound_result.encode);
      break;
    }

    case 0xa4d25b41: {
      const args = Protobuf.decode<ProtoNamespace.register_key_arguments>(
        contractArgs.args,
        ProtoNamespace.register_key_arguments.decode
      );
      const res = c.register_key(args);
      retbuf = Protobuf.encode(res, ProtoNamespace.register_key_result.encode);
      break;
    }

    case 0x758d61f2: {
      const args = Protobuf.decode<ProtoNamespace.ping_arguments>(
        contractArgs.args,
        ProtoNamespace.ping_arguments.decode
      );
      const res = c.ping(args);
      retbuf = Protobuf.encode(res, ProtoNamespace.ping_result.encode);
      break;
    }

    case 0xf43dc879: {
      const args = Protobuf.decode<ProtoNamespace.stress_arguments>(
        contractArgs.args,
        ProtoNamespace.stress_arguments.decode
      );
      const res = c.stress(args);
      retbuf = Protobuf.encode(res, ProtoNamespace.stress_result.encode);
      break;
    }

    case 0xdfd33796: {
      const args = Protobuf.decode<ProtoNamespace.sweep_arguments>(
        contractArgs.args,
        ProtoNamespace.sweep_arguments.decode
      );
      const res = c.sweep(args);
      retbuf = Protobuf.encode(res, ProtoNamespace.sweep_result.encode);
      break;
    }

    default:
      System.exit(1);
      break;
  }

  System.exit(0, retbuf);
  return 0;
}

main();
